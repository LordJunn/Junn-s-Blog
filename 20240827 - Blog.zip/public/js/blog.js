import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
import { getDatabase,get,ref } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-database.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
// grr copy ur own
 };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to get and display posts
function getPostData() {
    const user_ref = ref(db, 'post/');
    get(user_ref).then((snapshot) => {
        const data = snapshot.val();
        displayPosts(data);
    }).catch((error) => {
        console.error("Error fetching post data: ", error);
    });
}

// Function to display posts
function displayPosts(posts) {
    let html = "";
    const table = document.querySelector('.main');
    const searchTerm = document.querySelector('#searchInput').value.toLowerCase();
    
    for (const key in posts) {
        const { title, post_content } = posts[key];
        const sanitizedContent = post_content.replace(/\n/g, '<br>'); // Replace newline characters with <br> for line breaks

        // Filter posts based on search term
        if (key.toLowerCase().includes(searchTerm) ||
            title.toLowerCase().includes(searchTerm) ||
            sanitizedContent.toLowerCase().includes(searchTerm)) {
            html += `
                <div class="post"> 
                    <span class="post-id">#${key}</span>
                    <h2>${title}</h2>
                    <p>${sanitizedContent}</p>
                </div>
            `;
        }
    }
    
    table.innerHTML = html;
}

// Add event listener for search input
document.querySelector('#searchInput').addEventListener('input', () => {
    // Fetch and display posts whenever the search input changes
    getPostData();
});

// Initial call to display posts
getPostData();