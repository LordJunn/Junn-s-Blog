import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
import { getDatabase,get,ref } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-database.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDF83EeEAicKiZlVZiKf2Pm06IxAs7o0PA",
  authDomain: "junn-blogging.firebaseapp.com",
  projectId: "junn-blogging",
  storageBucket: "junn-blogging.appspot.com",
  messagingSenderId: "858042348484",
  appId: "1:858042348484:web:bd06dc1ebe00ac6c32aa91",
  databaseURL: "https://junn-blogging-default-rtdb.asia-southeast1.firebasedatabase.app",
  measurementId: "G-NFPFG5W0NK"    
 };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to get and display posts
function getPostData() {
    const user_ref = ref(db, 'post/');
    get(user_ref).then((snapshot) => {
        const data = snapshot.val();
        displayPosts(data);
    }).catch((error) => {
        console.error("Error fetching post data: ", error);
    });
}

// Function to display posts
function displayPosts(posts) {
    let html = "";
    const table = document.querySelector('.main');
    const searchTerm = document.querySelector('#searchInput').value.toLowerCase();

    // Get today's date in YYYYMMDD format
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');

    // Check if any post matched the search criteria
    let hasPosts = false;

    // Check if we need to display posts for today's date
    const showTodayPosts = searchTerm === 'fsjal';


    for (const key in posts) {
        const { title, post_content } = posts[key];
        const sanitizedContent = post_content.replace(/\n/g, '<br>'); // Replace newline characters with <br> for line breaks

        // Extract the date from the post ID
        const postDate = key.substring(0); // Remove the '#' character from the ID
        console.log("Post Date:", postDate); // Log post date

        // Determine if the post matches the search term
        const matchesSearchTerm = key.toLowerCase().includes(searchTerm) ||
                                  title.toLowerCase().includes(searchTerm) ||
                                  sanitizedContent.toLowerCase().includes(searchTerm);
        console.log("Matches Search Term:", matchesSearchTerm); // Log search term match


        // Determine if the post matches today's date
        const isTodayPost = postDate === today;
        console.log("Is Today Post:", isTodayPost); // Log if post is for today

        // Filter posts based on search term
        if (matchesSearchTerm || (isTodayPost && showTodayPosts)) {
            html += `
                <div class="post"> 
                    <span class="post-id">#${key}</span>
                    <h2>${title}</h2>
                    <p>${sanitizedContent}</p>
                </div>
            `;
            hasPosts = true; // Set flag indicating at least one post matches
        }
    }

    // Display message if no posts match
    if (!hasPosts) {
        html = `
            <div class="post"> 
                <span class="post-id">#ERROR</span>
                <h2 style="color: #450000" >No Posts Found</h2>
                <p>
                    Well, either it's an error, or there are no posts with that ID, Title, or Content. Please use another query.<br>
                    But... If you're here to debug, let me show you some stuff.<br><br>

                    Todays date: ${today}
                    Are there any valid posts here: ${hasPosts}

                </p>
            </div>
        `;
    }

    console.log("Search Term:", searchTerm); // Log search term
    console.log("Today's Date:", today); // Log today's date
    console.log("Show Today's Posts:", showTodayPosts); // Log if today's posts should be shown
    

    table.innerHTML = html;
}

// Search bar placeholder text gaming
const searchInput = document.getElementById('searchInput');
const placeholders = [
    'Search by ID, Title, or Content',
    'For post of the day, type in fsjal.'
];
let currentIndex = 0;
let currentText = '';
let isTyping = true;
const typingSpeed = 100; // Speed of typing in milliseconds
const deletingSpeed = 50; // Speed of deleting in milliseconds

function typeEffect() {
    if (isTyping) {
        // Typing effect
        if (currentText.length < placeholders[currentIndex].length) {
            currentText += placeholders[currentIndex][currentText.length];
            searchInput.placeholder = currentText;
            setTimeout(typeEffect, typingSpeed);
        } else {
            isTyping = false;
            setTimeout(typeEffect, 2000); // Pause before starting to delete
        }
    } else {
        // Deleting effect
        if (currentText.length > 0) {
            currentText = currentText.slice(0, -1);
            searchInput.placeholder = currentText;
            setTimeout(typeEffect, deletingSpeed);
        } else {
            isTyping = true;
            currentIndex = (currentIndex + 1) % placeholders.length; // Move to next placeholder
            setTimeout(typeEffect, 500); // Pause before starting to type the next placeholder
        }
    }
}

// Start the typing effect
typeEffect();

// Add event listener for search input
document.querySelector('#searchInput').addEventListener('input', () => {
    // Fetch and display posts whenever the search input changes
    getPostData();
});

// Initial call to display posts
getPostData();  