
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
  import { getAuth,signInWithEmailAndPassword,onAuthStateChanged, signOut  } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-auth.js";
  import { getDatabase,set,ref,get,remove,update } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-database.js";

  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
   apiKey: "AIzaSyDF83EeEAicKiZlVZiKf2Pm06IxAs7o0PA",
   authDomain: "junn-blogging.firebaseapp.com",
   projectId: "junn-blogging",
   storageBucket: "junn-blogging.appspot.com",
   messagingSenderId: "858042348484",
   appId: "1:858042348484:web:bd06dc1ebe00ac6c32aa91",
   databaseURL: "https://junn-blogging-default-rtdb.asia-southeast1.firebasedatabase.app",
   measurementId: "G-NFPFG5W0NK"    
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);

  const auth = getAuth(app)
  const db = getDatabase(app)

  const my_blog = document.querySelector('.my_blog')
  const login_page = document.querySelector('.login')

  onAuthStateChanged(auth,(user)=>{
     if(user){
        my_blog.classList.add('show')
        login_page.classList.add('hide')
     }else{
        my_blog.classList.remove('show')
        login_page.classList.remove('hide')
     }
  })
  

  function SignInUSer() {
   
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    signInWithEmailAndPassword (auth,email,password).then((userCredinals)=>{
         console.log(userCredinals.user.uid);
    })
  }

  const Sign_btn = document.querySelector('#sign_in')
  Sign_btn.addEventListener('click',SignInUSer)

//   sign Out Logout 

 const sign_out_btn = document.querySelector('#logout')
 sign_out_btn.addEventListener('click',()=>{
    signOut(auth).then(()=>{
        //  
    }).catch((error)=>{
        console.log("error" + error);
    })
 })

//  ------------
// Blog section code 

const notify = document.querySelector('.notifiy')

const add_post_Btn  = document.querySelector('#post_btn')

document.querySelector('#post_content').addEventListener('input', function() {
    this.style.height = 'auto'; // Reset height
    this.style.height = `${this.scrollHeight}px`; // Set height to content height
});


document.addEventListener('DOMContentLoaded', (event) => {
    const idField = document.querySelector('#post_id');
    const titleField = document.querySelector('#title');

    // Function to convert "fsjal" to today's date
    function updateFieldsFromFSJAL() {
        if (idField.value.toLowerCase() === 'fsjal') {
            // Get today's date
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
            const dd = String(today.getDate()).padStart(2, '0');

            // Format ID and Title
            const formattedId = `${yyyy}${mm}${dd}`;
            const monthNames = ["January", "February", "March", "April", "May", "June",
                                "July", "August", "September", "October", "November", "December"];
            const monthName = monthNames[today.getMonth()];
            const formattedTitle = `${monthName} ${dd}, ${yyyy}`;

            // Update fields with formatted values
            idField.value = formattedId;
            titleField.value = formattedTitle;
        }
    }

    // Add event listener to ID field for input changes
    idField.addEventListener('input', updateFieldsFromFSJAL);
});

function Add_Post() {
    const idField = document.querySelector('#post_id');
    const titleField = document.querySelector('#title');
    const postContentField = document.querySelector('#post_content');
    const id = idField.value;
    const post_content = postContentField.value;

    // Validate ID: Ensure it is a number and not empty
    if (!id || isNaN(id)) {
        notify.innerHTML = "Invalid ID. Please enter only numbers.";
        return;
    }

    const postRef = ref(db, 'post/' + id);

    // Check if ID already exists
    get(postRef).then((snapshot) => {
        if (snapshot.exists()) {
            notify.innerHTML = `ID ${id} already exists. Please choose a different ID.`;
        } else {
            // ID is unique, proceed to add the post
            set(postRef, {
                title: titleField.value,
                post_content: post_content
            }).then(() => {
                notify.innerHTML = `Post #${id} published`;
                idField.value = "";
                titleField.value = "";
                postContentField.value = "";
                GetPostData();
            }).catch((error) => {
                console.error("Error adding post: ", error);
                notify.innerHTML = "Error adding post.";
            });
        }
    }).catch((error) => {
        console.error("Error checking ID: ", error);
        notify.innerHTML = "Error checking ID.";
    });
}

add_post_Btn.addEventListener('click', Add_Post);

// Get Data from Firebase DB
function GetPostData(searchQuery = '') {
    const user_ref = ref(db, 'post/');

    get(user_ref).then((snapshot) => {
        const data = snapshot.val();
        let html = "";
        const table = document.querySelector('table');

        // Get today's date in YYYYMMDD format
        const today = new Date().toISOString().split('T')[0].replace(/-/g, '');

        // Check if any post matched the search criteria
        let hasPosts = false;

        // Convert search query to lowercase
        const lowerSearchQuery = searchQuery.toLowerCase();

        // Check if we need to display posts for today's date
        const showTodayPosts = lowerSearchQuery === 'fsjal';
        
        for (const key in data) {
            const { title, post_content } = data[key];

            const postDate = key.substring(0);

            // Check if the title or post content matches the search query
            const matchesSearchTerm = key.includes(searchQuery.toLowerCase()) ||
                                      title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                      post_content.toLowerCase().includes(searchQuery.toLowerCase());

            // Determine if the post matches today's date
            const isTodayPost = postDate === today;

            if (matchesSearchTerm || (isTodayPost && showTodayPosts)) {
                html += `
                    <tr>
                        <td>${key}</td>
                        <td>${title}</td>
                        <td><button class="delete" onclick="delete_data('${key}')">Delete</button></td>
                        <td><button class="update" onclick="update_data('${key}')">Update</button></td>
                    </tr>
                `;
                hasPosts = true;
            }
        }

        if (!hasPosts) {
            html = '<tr><td colspan="4">No posts found</td></tr>';
        }

        table.innerHTML = html;
    }).catch((error) => {
        console.error("Error fetching post data: ", error);
        notify.innerHTML = "Error fetching post data.";
    });
}

// Call the function to initially populate data
GetPostData();

//  delete_data

window.delete_data = function(key){
  
     remove(ref(db,`post/${key}`))
     notify.innerHTML =`Post #${key} Deleted`
     GetPostData()

}

// height changer
function autoResizeTextarea(textarea) {
    textarea.style.height = 'auto'; // Reset height
    textarea.style.height = `${textarea.scrollHeight}px`; // Set height to content height
}

// Function to populate fields for update
window.update_data = function(key) {
   const user_ref = ref(db, `post/${key}`);
   get(user_ref).then((item) => {
       const { title, post_content } = item.val();
       document.querySelector('#post_id').value = key;
       document.querySelector('#title').value = title;
       document.querySelector('#post_content').value = post_content;

        // Adjust textarea height after populating
        autoResizeTextarea(document.querySelector('#post_content'));

       document.querySelector('#update_btn').style.display = 'inline-block';
       document.querySelector('#post_btn').style.display = 'none';
   }).catch((error) => {
       console.error("Error fetching post for update: ", error);
   });
}

// Function to handle form update
function Update_Form() {

   // Adjust textarea height after populating
   autoResizeTextarea(document.querySelector('#post_content'));

   const id = document.querySelector('#post_id').value;
   const title = document.querySelector('#title').value;
   const post_content = document.querySelector('#post_content').value;

   if (!id || isNaN(id)) {
       notify.innerHTML = "Invalid ID. Please enter a number.";
       return;
   }

   const postRef = ref(db, `post/${id}`);
   update(postRef, {
       title: title,
       post_content: post_content
   }).then(() => {
       notify.innerHTML = `Post #${id} updated.`;
       document.querySelector('#title').value = "";
       document.querySelector('#post_content').value = "";
       document.querySelector('#post_id').value = "";
       document.querySelector('#update_btn').style.display = 'none';
       document.querySelector('#post_btn').style.display = 'inline-block';
       GetPostData();
   }).catch((error) => {
       console.error("Error updating post: ", error);
       notify.innerHTML = "Error updating post.";
   });

}

// Event listener for the update button
document.querySelector('#update_btn').addEventListener('click', Update_Form);

document.querySelector('#searchInput').addEventListener('input', (event) => {
    const searchQuery = event.target.value;
    GetPostData(searchQuery);
});




// Initial data fetch
GetPostData();